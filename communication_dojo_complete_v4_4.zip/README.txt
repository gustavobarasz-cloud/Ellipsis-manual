THE COMMUNICATION DOJO — COMPLETE SUITE (v4.4)
==============================================
All five manuals are 100% self-contained, offline-capable HTML apps with localStorage persistence, JSON backup/restore, Markdown (.md) export, and 1-page printable field cards.

CONTENTS
--------
1. white_belt_manual_v4_4.html   (Guard & Regulate · W1–W6 · Key: dojo_white_belt_v4)
2. blue_belt_manual_v4_4.html    (Read & Bond · B1–B6 · Key: dojo_blue_belt_v4)
3. brown_belt_manual_v4_3.html   (Word, Reveal & Steer · Br1–Br6 · Key: dojo_brown_belt_v4)
4. black_belt_manual_v4_3.html   (Systems & Bridges · Bk1–Bk6 · Key: dojo_black_belt_v4)
5. sanctuary_manual_v4_4.html    (Parallel I-Thou Track · S1–S4 · Key: dojo_sanctuary_v4)

HOW TO USE
----------
- Open any .html file directly in Chrome, Edge, Safari, or Firefox (desktop or mobile).
- Keep the four Belt manuals for Dojo practice (pressure, power, stakes) and open sanctuary_manual_v4_4.html as your unified I-Thou space (all 13 Sanctuary modules S1.1–S4.3 + unified 3-line Sanctuary Journal + Relational Immunity Map).
- Pocket Card Questions:
  * White:     "Would I accept their no?"
  * Blue:      "Which conversation are they in?"
  * Brown:     "What reality are my words building?"
  * Black:     "Am I a bridge here, or a code-switcher?"
  * Sanctuary: "Am I here, and are they?"
